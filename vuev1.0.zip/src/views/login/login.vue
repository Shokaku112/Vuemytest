<template>
    <div style="width: 340px;height: 600px;left:40%;top:70px;position: relative;border-radius: 10px"
         class="bg-info">
        {{msg}}
        <div style="width: 310px;height: 180px;background: none;left: 10%;margin-left: 15px;text-align: center">
            <img src="../../../public/image/3.jpg" style="max-width: 75%;margin-top: 15px">
            <p>让创作变得更有趣</p>
        </div>
        <div style="width: 300px;height: 150px;background: none;text-align: center;position:relative;left:6%;top:15% ">
            <form role="form">
                <div class="form-group">
                    <input style="height:40px" type="text" class="form-control" v-model="form.username"
                           placeholder="请输入用户名或者邮箱">
                    <input style="height:40px" type="password" class="form-control" v-model="form.userpwd"  placeholder="请输入密码">

                        <button @click="toogleMenu(form.username,form.userpwd)" style="width: 125px;height:40px;margin: 10px;display: inline;margin-top: 20px" type="submit" class="btn btn-info" >登录</button>
                    <button @click="addUser(form.username,form.userpwd)" style="width: 125px;height:40px;margin: 10px;display: inline;margin-top: 20px" type="submit" class="btn btn-info" >注册</button>
                    <a href="#" style="float: right">forget password?</a>
                </div>
            </form>
        </div>
    </div>
</template>


<script>
    import {realconsole} from '../../../public/bower_components/jquery/dist/jquery.js'
    import {realconsole2} from '../../../public/bower_components/bootstrap/dist/js/bootstrap.js'
    export default
    {
        watch:{},
        props:{},
        created:{},
        mounted:{},//作用类似于windows.onload
        methods:
            {
                methods1:function () {
                realconsole();
                realconsole2();
            },
                toogleMenu(username,pwd)
                {
                    console.log(username,pwd);
                },
                addUser(userName,userPassword)
                {
                    var name = userName;
                    var userpwd = userPassword;
                    this.$http.post('http://localhost:3000/api/user/addUser', {
                        username: name,
                        userpassword: userpwd
                    }, {}).then((response) => { console.log(response); })
                }


            },
        data(){
            return{
                form:
                    {
                        username:"",
                        userpwd:"",
                    },
                //动态绑定组件（好处：如果要生成多一个一样的模板标签或者组件可以直接通过该方法复制粘贴使用v-for=“item in tab（数组名字)”）
            data1:[
                {txt:"登陆",status1:true},
                {txt:"注册",status1:true}
            ],
                isActive:1

        }},
        name: "login"
    }

</script>


<style scoped>
@import "../../../public/bower_components/bootstrap/dist/css/bootstrap.css";
</style>
// sql语句

var sqlMap = {
    user: {
        add: 'insert into account values (null,?,?)'
    }

}

module.exports = sqlMap
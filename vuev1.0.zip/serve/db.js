
module.exports = {
    mysql: {
        host: 'localhost',
        user: 'root',
        password: '123456',
        database: 'user',
        port: '3306'
    }
}